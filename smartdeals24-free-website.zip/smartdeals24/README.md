SMARTDEALS24 FREE AFFILIATE WEBSITE

1. Upload index.html and style.css to a public GitHub repository.
2. GitHub: Settings > Pages > Deploy from branch > main > /root.
3. Your free address will look like: https://YOUR-USERNAME.github.io/REPOSITORY/
4. Replace YOUR_AFFILIATE_LINK_1 through YOUR_AFFILIATE_LINK_18 with your approved affiliate links.
5. Replace SmartDeals24 with your preferred brand name if desired.

The site is static, responsive, and requires no paid hosting or database.

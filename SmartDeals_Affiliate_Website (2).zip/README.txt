# SmartDeals Affiliate Website

This is a free static affiliate marketing website.

## How to use
1. Open `index.html` in a browser to preview it.
2. Replace each `https://example.com` in `index.html` with your real affiliate URL.
3. Change the brand name "SmartDeals" to your preferred website name.
4. Upload `index.html`, `style.css`, and `script.js` to any static/free web hosting service you choose.

## Important
The current product links are placeholders. They are NOT real affiliate links.

The website includes an affiliate disclosure and uses `rel="nofollow sponsored"` on outbound affiliate links.
